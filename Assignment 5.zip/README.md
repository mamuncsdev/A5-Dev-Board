## **📅 Deadline For 60 marks**: 2nd March , 2025 ( 11:59 pm ⏱️)

## **📅 Deadline For 50 marks**: 3rd March , 2025 ( 11:59 pm ⏱️)

**📅 Deadline For 30 marks**: Any time after 3rd March , 2025.
---
🏆 Requirements
---
Follow the given  video strictly to meet all the requirements and Challenges.

---
Required Question to Answer at Blog.html
---
- Question-1: What are the different ways to select an element in the DOM?

- Question-2: What is the difference between innerHTML, innerText, and textContent ?

- Question-3: What is event delegation in the DOM?

- Question-4: What is event bubbling in the DOM?

- Question-5: How do you create, add, and remove elements using JavaScript?
